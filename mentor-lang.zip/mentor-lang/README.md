# Mentor

**A programming language that mentors you.**

Mentor is a small, friendly language for people writing their very first programs.
When you make a mistake, the compiler doesn't just yell at you. It **fixes the mistake,
tells you exactly what it fixed, shows you the corrected code, and then runs it.**

```text
$ cat oops.mentor
vr x = 10
pritn x
if x > 5
 print "hello"

$ python mentor.py oops.mentor
I fixed these mistakes:
1. Line 1: "vr" → corrected to "var"
2. Line 2: "pritn" → corrected to "print"
3. Line 3: missing "then" after the if condition — added it
4. Line 3: missing "end" at the end of the if block — added it

Corrected code:
var x = 10
print x
if x > 5 then
  print "hello"
end

Running the program...
10
hello
```

Beginners learn fastest from feedback they can read and act on. Mentor turns every
mistake into a tiny lesson instead of a wall of red text.

## Quick start

You only need Python 3.8 or newer. There is nothing to install.

```bash
git clone https://github.com/YOUR-USERNAME/mentor-lang.git
cd mentor-lang
python mentor.py examples/hello.mentor
```

Try the program that is full of mistakes:

```bash
python mentor.py examples/mistakes.mentor
```

## The language in one minute

```text
# variables and printing
var name = "Ada"
print "Hello, " + name

# decisions
var age = 16
if age >= 18 then
  print "adult"
else
  print "not yet"
end

# loops
var x = 3
while x > 0 then
  print x
  x = x - 1
end

# functions
func add(a, b)
  return a + b
end
print add(3, 7)
```

- Blocks end with `end`. No curly braces, no semicolons.
- `if` and `while` are followed by `then`.
- Numbers, text (`"double quotes"`), and `true` / `false`.
- Math: `+ - * / %`. Comparisons: `== != < > <= >=`. Logic: `and`, `or`.
- Comments start with `#`.

See [docs/syntax.md](docs/syntax.md) for the full reference.

## What Mentor fixes

| You wrote | Mentor does |
|---|---|
| `vr`, `pritn`, `whlie`, `fucn`, `retrun`, `Print` | Corrects the keyword |
| `if x > 5` (no `then`) | Adds `then` |
| `while x > 0 do`, `if x > 5:` | Replaces `do` / `:` with `then` |
| a block that is never closed | Adds the missing `end` (uses your indentation to find the right spot) |
| `endif`, `end while`, `}` | Turns them into `end` |
| `x = 5` before `var x` | Adds `var` |
| `scroe` when you have `score` | Corrects the variable name |
| `if x = 5` | Changes it to `==` |
| `&&`, `\|\|` | Changes them to `and`, `or` |
| `x += 1`, `x++` | Rewrites as `x = x + 1` |
| missing `)` or closing quote | Adds it |
| `let`, `def`, `echo`, `elif` | Translates to the Mentor equivalent |

Every fix is listed with its line number, so you always see what changed and why.
Details: [docs/mistake-recovery.md](docs/mistake-recovery.md).

Mentor can only fix mistakes it is confident about. Anything else gets a plain-English
error message with the line of code, and "did you mean...?" hints for misspelled names.

## Command line

```bash
python mentor.py program.mentor            # fix, explain, run
python mentor.py program.mentor --check    # show fixes only, don't run
python mentor.py program.mentor --write    # save the corrected code to the file
python mentor.py program.mentor --strict   # turn off automatic fixing
```

## Project layout

```text
mentor-lang/
├── mentor.py          # recovery system + lexer + parser + interpreter
├── examples/          # sample programs (mistakes.mentor is the fun one)
├── docs/              # syntax reference, how recovery works, launch kit
└── tests/             # python -m unittest discover -s tests
```

## How it works

1. **Recovery** reads each line, spots likely mistakes, and rewrites it. It also records every change.
2. The corrected code goes through the normal **lexer**, **parser** and **tree-walking interpreter**.

The recovery pass is deliberately cautious: it only changes things when the evidence is strong,
and it never changes what a correct program does.

## Roadmap

- `for` loops and lists
- An interactive prompt (REPL)
- Explain mode: a short lesson with each fix
- A browser playground

## Contributing

Ideas and pull requests are welcome, especially new beginner mistakes to recover from.
See [CONTRIBUTING.md](CONTRIBUTING.md).

## License

MIT. See [LICENSE](LICENSE).
