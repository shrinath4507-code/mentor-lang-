#!/usr/bin/env python3
"""
Mentor - a programming language that mentors you.

Mentor is an educational language for beginners. Its compiler does not just
complain about mistakes: it fixes the common ones, tells you exactly what it
fixed, shows you the corrected code, and then runs it.

Pipeline:   source --> Recovery (fix mistakes) --> Lexer --> Parser --> Interpreter

Usage:
    python mentor.py program.mentor            # fix, show fixes, run
    python mentor.py program.mentor --check    # only show fixes, don't run
    python mentor.py program.mentor --write    # save the corrected code to the file
    python mentor.py program.mentor --strict   # no automatic fixing

No dependencies. Python 3.8+.
"""
from __future__ import annotations

import argparse
import difflib
import math
import re
import sys
from collections import namedtuple
from dataclasses import dataclass

__version__ = "0.1.0"

# ---------------------------------------------------------------------------
# Language definition
# ---------------------------------------------------------------------------

KEYWORDS = {
    "var", "print", "if", "then", "else", "end", "while",
    "func", "return", "and", "or", "true", "false",
}

# Keywords that can start a statement (used to spot typos like "pritn").
STATEMENT_KEYWORDS = ["var", "print", "if", "else", "end", "while", "func", "return"]

# Words from other languages that beginners often type.
ALIASES = {
    "let": "var", "const": "var", "int": "var", "float": "var",
    "string": "var", "str": "var",
    "echo": "print", "display": "print", "printf": "print",
    "println": "print", "puts": "print",
    "function": "func", "def": "func", "fn": "func",
    "elif": "else", "elsif": "else", "elseif": "else", "otherwise": "else",
    "endif": "end", "endwhile": "end", "endfunc": "end", "done": "end",
}

ASSIGN_OPS = {"=", "+=", "-=", "*=", "/=", "%=", "++", "--"}
BLOCK_OPENERS = ("do", ":", "{")

MAX_STEPS = 1_000_000   # safety net against endless loops
MAX_DEPTH = 200         # safety net against endless recursion


class MentorError(Exception):
    """An error in a Mentor program (carries a line number)."""

    def __init__(self, line: int, message: str):
        super().__init__(message)
        self.line = line
        self.message = message


# ---------------------------------------------------------------------------
# Tokenizing (shared by the recovery system and the real lexer)
# ---------------------------------------------------------------------------

Tok = namedtuple("Tok", "kind text")

_TOKEN_RE = re.compile(
    r"(?P<ws>[ \t\r]+)"
    r"|(?P<comment>\#.*|//.*)"
    r"|(?P<semi>;)"
    r"|(?P<string>\"[^\"\n]*\"?|'[^'\n]*'?)"
    r"|(?P<number>\d+(?:\.\d+)?)"
    r"|(?P<ident>[A-Za-z_][A-Za-z0-9_]*)"
    r"|(?P<op>==|!=|<=|>=|&&|\|\||\+\+|--|\+=|-=|\*=|/=|%=|[-+*/%()<>=,:{}!])"
    r"|(?P<other>.)"
)


def tokenize_line(line):
    """Split one line into tokens. Returns (tokens, comment_or_None)."""
    toks, comment = [], None
    for m in _TOKEN_RE.finditer(line):
        kind, text = m.lastgroup, m.group()
        if kind in ("ws", "semi"):
            continue
        if kind == "comment":
            comment = text
            continue
        toks.append(Tok(kind, text))
    return toks, comment


def similar(word, candidates, cutoff=0.75):
    """Best 'did you mean' match for `word` among `candidates`, or None.

    Catches wrong capitalisation, swapped letters ("pritn") and small typos.
    """
    w = word.lower()
    lookup = {}
    for c in candidates:
        lookup.setdefault(c.lower(), c)
    if w in lookup:
        return lookup[w]
    for lc, c in lookup.items():
        if len(lc) == len(w) and len(w) >= 2 and sorted(lc) == sorted(w):
            return c
    m = difflib.get_close_matches(w, list(lookup), n=1, cutoff=cutoff)
    return lookup[m[0]] if m else None


def is_operand(tok):
    """True if the token can end a value (number, text, name, true/false, ')')."""
    if tok.kind in ("number", "string"):
        return True
    if tok.kind == "ident":
        return tok.text.lower() not in KEYWORDS - {"true", "false"}
    return tok.text == ")"


def render(toks):
    """Turn tokens back into neatly spaced source text."""
    out, prev, prev_unary = "", None, False
    word_kw = KEYWORDS - {"true", "false"}
    for t in toks:
        if prev is None:
            out = t.text
        elif t.text in (")", ","):
            out += t.text
        elif prev.text == "(" or prev_unary:
            out += t.text
        elif t.text == "(" and prev.kind == "ident" and prev.text.lower() not in KEYWORDS:
            out += t.text
        else:
            out += " " + t.text
        prev_unary = t.text == "-" and (
            prev is None
            or (prev.kind == "op" and prev.text != ")")
            or (prev.kind == "ident" and prev.text.lower() in word_kw)
        )
        prev = t
    return out


# ---------------------------------------------------------------------------
# Mistake recovery - the heart of Mentor
# ---------------------------------------------------------------------------

@dataclass
class Fix:
    line: int
    message: str

    def __str__(self):
        return f"Line {self.line}: {self.message}"


@dataclass
class Block:
    kind: str                 # "if", "while" or "func"
    line: int                 # line where the block starts
    indent: int               # indentation of the header line
    body_indent: object = None  # indentation of the first body line


@dataclass
class RecoveryResult:
    code: str
    fixes: list


class Recovery:
    """Reads sloppy Mentor code and produces clean code plus a list of fixes."""

    def __init__(self, source):
        self.lines = source.splitlines()
        self.fixes = []
        self.out = []          # (depth, text) pairs; depth None = blank line
        self.stack = []        # currently open blocks
        self.scopes = [set()]  # declared variable names, one set per scope
        self.names = set()     # every variable / function / parameter name
        self.funcs = set()     # every function name
        self.cur_indent = 0

    # -- small helpers ------------------------------------------------------

    def fix(self, line, message):
        self.fixes.append(Fix(line, message))

    def is_declared(self, name):
        return any(name in s for s in self.scopes)

    def declared_names(self):
        return set().union(*self.scopes)

    def declare(self, name):
        self.scopes[-1].add(name)

    def fix_keyword(self, ln, toks, kw):
        if toks[0].text != kw:
            self.fix(ln, f'"{toks[0].text}" \u2192 corrected to "{kw}"')
            toks[0] = Tok("ident", kw)
        return toks

    # -- passes ---------------------------------------------------------------

    def prescan(self):
        """First pass: learn every name the program creates."""
        for raw in self.lines:
            toks, _ = tokenize_line(raw)
            if not toks or toks[0].text == "}":
                continue
            kw = self.classify(toks)
            if kw == "func" and len(toks) > 1 and toks[1].kind == "ident":
                self.funcs.add(toks[1].text)
                for t in toks[1:]:
                    if t.kind == "ident" and t.text.lower() not in KEYWORDS:
                        self.names.add(t.text)
            elif kw == "var" and len(toks) > 1 and toks[1].kind == "ident":
                self.names.add(toks[1].text)
            elif (kw is None and toks[0].kind == "ident"
                  and len(toks) > 1 and toks[1].text in ASSIGN_OPS):
                self.names.add(toks[0].text)

    def classify(self, toks):
        """Which statement does this line start? (None = assignment/expression)"""
        first = toks[0]
        if first.text == "}":
            return "end"
        if first.kind != "ident":
            return None
        w = first.text.lower()
        if w in STATEMENT_KEYWORDS:
            return w
        nxt = toks[1].text if len(toks) > 1 else ""
        if nxt in ASSIGN_OPS:
            return None
        if w in ALIASES:
            return ALIASES[w]
        if first.text in self.funcs and nxt == "(":
            return None
        if first.text in self.names:
            return None
        return similar(w, STATEMENT_KEYWORDS)

    def run(self):
        self.prescan()
        for ln, raw in enumerate(self.lines, 1):
            expanded = raw.expandtabs(4)
            indent = len(expanded) - len(expanded.lstrip())
            toks, comment = tokenize_line(raw)
            if not toks:
                if comment:
                    self.out.append((len(self.stack), comment))
                else:
                    self.out.append((None, ""))
                continue
            self.cur_indent = indent
            self.handle(ln, toks, comment, indent, raw.strip())

        while self.stack:                       # blocks still open at the end
            block = self.stack.pop()
            if block.kind == "func":
                self.scopes.pop()
            self.fix(block.line, f'missing "end" at the end of the {block.kind} block \u2014 added it')
            self.out.append((len(self.stack), "end"))

        lines = ["" if d is None else "  " * d + text for d, text in self.out]
        code = "\n".join(lines).rstrip("\n") + "\n"
        self.fixes.sort(key=lambda f: f.line)   # stable: keeps order within a line
        return RecoveryResult(code, self.fixes)

    # -- one statement ----------------------------------------------------------

    def handle(self, ln, toks, comment, indent, orig):
        before = len(self.fixes)
        toks = list(toks)

        if toks[0].text == "}" and len(toks) > 1 and toks[1].text.lower() in ("else", "elif", "elseif"):
            self.fix(ln, '"}" removed \u2014 Mentor closes blocks with "end", not braces')
            toks = toks[1:]

        kw = self.classify(toks)

        tail_end = False
        if kw != "end" and len(toks) > 1 and toks[-1].kind == "ident" and toks[-1].text.lower() == "end":
            toks = toks[:-1]
            tail_end = True
            self.fix(ln, '"end" belongs on its own line \u2014 moved it there')

        if indent is not None:
            self.close_by_indent(ln, indent, kw)
        cur_indent = indent if indent is not None else self.cur_indent

        remainder, drop, depth = [], False, len(self.stack)

        if kw == "var":
            toks = self.stmt_var(ln, toks)
        elif kw == "print":
            toks = self.fix_keyword(ln, toks, "print")
            toks = [toks[0]] + self.fix_expr(ln, toks[1:])
        elif kw == "return":
            toks = self.fix_keyword(ln, toks, "return")
            toks = [toks[0]] + self.fix_expr(ln, toks[1:])
        elif kw in ("if", "while"):
            toks, remainder = self.stmt_header(ln, toks, kw)
            self.stack.append(Block(kw, ln, cur_indent))
        elif kw == "func":
            toks, params = self.stmt_func(ln, toks)
            self.stack.append(Block("func", ln, cur_indent))
            self.scopes.append(set(params))
        elif kw == "else":
            if self.stack and self.stack[-1].kind == "if":
                toks, remainder = self.stmt_else(ln, toks)
                depth = len(self.stack) - 1
                self.stack[-1].body_indent = None
            else:
                self.fix(ln, '"else" has no matching "if" \u2014 removed it')
                drop = True
        elif kw == "end":
            toks, remainder = self.stmt_end(ln, toks)
            if self.stack:
                block = self.stack.pop()
                if block.kind == "func":
                    self.scopes.pop()
                depth = len(self.stack)
            else:
                self.fix(ln, 'stray "end" with nothing to close \u2014 removed it')
                drop = True
        else:
            toks = self.stmt_other(ln, toks)
            if not toks:
                drop = True

        if not drop:
            changed = len(self.fixes) > before
            if orig is not None and not changed:
                text = orig
            else:
                text = render(toks) + (("  " + comment) if comment else "")
            self.out.append((depth, text))
        if remainder:
            self.handle(ln, remainder, None, None, None)
        if tail_end:
            self.handle(ln, [Tok("ident", "end")], None, None, None)

    def close_by_indent(self, ln, indent, kw):
        """If a block's body was indented and this line is not, the block is over."""
        while self.stack:
            top = self.stack[-1]
            if top.body_indent is None:
                if kw != "end":
                    top.body_indent = indent
                return
            closes = (top.body_indent > top.indent and indent <= top.indent
                      and kw != "end" and not (kw == "else" and top.kind == "if"))
            if not closes:
                return
            self.stack.pop()
            if top.kind == "func":
                self.scopes.pop()
            self.fix(top.line, f'missing "end" at the end of the {top.kind} block \u2014 added it before line {ln}')
            self.out.append((len(self.stack), "end"))

    # -- statement kinds --------------------------------------------------------

    def stmt_var(self, ln, toks):
        toks = self.fix_keyword(ln, toks, "var")
        rest = toks[1:]
        if not rest or rest[0].kind != "ident":
            return toks
        name, after = rest[0], rest[1:]
        if not after:
            self.fix(ln, f'"{name.text}" had no value \u2014 gave it the starting value 0')
            after = [Tok("op", "="), Tok("number", "0")]
        elif after[0].text == "=":
            pass
        elif after[0].text == "==":
            self.fix(ln, '"==" \u2192 corrected to "=" (a single = gives a variable its value)')
            after[0] = Tok("op", "=")
        else:
            self.fix(ln, f'missing "=" after "{name.text}" \u2014 added it')
            after = [Tok("op", "=")] + after
        value = self.fix_expr(ln, after[1:])
        self.declare(name.text)
        return [toks[0], name, Tok("op", "=")] + value

    def stmt_header(self, ln, toks, kw):
        """if / while lines: make sure the condition ends with 'then'."""
        toks = self.fix_keyword(ln, toks, kw)
        rest, remainder = toks[1:], []
        idx = next((i for i, t in enumerate(rest)
                    if t.kind == "ident" and t.text.lower() == "then"), None)
        if idx is not None:
            if rest[idx].text != "then":
                self.fix(ln, f'"{rest[idx].text}" \u2192 corrected to "then"')
            cond, remainder = rest[:idx], rest[idx + 1:]
        else:
            last = rest[-1] if rest else None
            if last is not None and last.text.lower() in BLOCK_OPENERS:
                self.fix(ln, f'"{last.text}" \u2192 corrected to "then"')
                cond = rest[:-1]
            elif (last is not None and last.kind == "ident" and len(rest) >= 2
                  and is_operand(rest[-2]) and last.text.lower() not in ("and", "or")):
                if similar(last.text, ["then"]):
                    self.fix(ln, f'"{last.text}" \u2192 corrected to "then"')
                else:
                    self.fix(ln, f'"{last.text}" doesn\'t belong here \u2014 replaced it with "then"')
                cond = rest[:-1]
            else:
                self.fix(ln, f'missing "then" after the {kw} condition \u2014 added it')
                cond = rest
        cond = self.fix_expr(ln, cond, cond=True)
        return [toks[0]] + cond + [Tok("ident", "then")], remainder

    def stmt_else(self, ln, toks):
        word, rest = toks[0].text.lower(), toks[1:]
        if word in ("elif", "elsif", "elseif"):
            self.fix(ln, f'"{toks[0].text}" isn\'t part of Mentor \u2014 wrote "else" with a nested "if" instead')
            return [Tok("ident", "else")], [Tok("ident", "if")] + rest
        toks = self.fix_keyword(ln, toks, "else")
        if rest and rest[0].kind == "ident" and rest[0].text.lower() == "if":
            self.fix(ln, '"else if" isn\'t part of Mentor \u2014 put the "if" on its own line inside the else')
            return [toks[0]], rest
        if rest and rest[0].text.lower() in ("then",) + BLOCK_OPENERS:
            self.fix(ln, f'"{rest[0].text}" is not used after else \u2014 removed it')
            rest = rest[1:]
        return [toks[0]], rest

    def stmt_func(self, ln, toks):
        toks = self.fix_keyword(ln, toks, "func")
        rest = toks[1:]
        if not rest or rest[0].kind != "ident":
            return toks, []
        name, after = rest[0], rest[1:]
        if after and after[-1].text.lower() in ("then",) + BLOCK_OPENERS:
            self.fix(ln, f'"{after[-1].text}" is not used after func \u2014 removed it')
            after = after[:-1]
        fixed_parens = False
        if after and after[0].text == "(":
            inner = after[1:]
            if inner and inner[-1].text == ")":
                inner = inner[:-1]
            else:
                self.fix(ln, 'missing ")" in the function definition \u2014 added it')
                fixed_parens = True
        else:
            inner = after
            self.fix(ln, f'missing parentheses after "{name.text}" \u2014 added them')
            fixed_parens = True
        params = [t for t in inner if t.kind == "ident"]
        if not fixed_parens and [t.text for t in inner] != ", ".join(p.text for p in params).replace(", ", " , ").split():
            self.fix(ln, "tidied the parameter list (parameters are separated by commas)")
        out = [toks[0], name, Tok("op", "(")]
        for k, p in enumerate(params):
            if k:
                out.append(Tok("op", ","))
            out.append(p)
        out.append(Tok("op", ")"))
        return out, [p.text for p in params]

    def stmt_end(self, ln, toks):
        toks = self.fix_keyword(ln, toks, "end")
        rest = toks[1:]
        if rest and rest[0].kind == "ident" and rest[0].text.lower() in ("if", "while", "func", "function"):
            self.fix(ln, f'"end {rest[0].text}" \u2192 corrected to "end" (every block just ends with "end")')
            rest = rest[1:]
        return [toks[0]], rest

    def stmt_other(self, ln, toks):
        first = toks[0]
        if len(toks) == 1 and first.text.lower() == "then":
            self.fix(ln, '"then" belongs at the end of the if/while line \u2014 removed this extra line')
            return None
        if len(toks) == 1 and first.text == "{":
            self.fix(ln, '"{" removed \u2014 Mentor does not use braces')
            return None
        if first.kind == "ident" and len(toks) > 1 and toks[1].text in ASSIGN_OPS:
            return self.stmt_assign(ln, toks)
        return self.fix_expr(ln, toks)

    def stmt_assign(self, ln, toks):
        name, op, rest = toks[0].text, toks[1].text, toks[2:]
        if not self.is_declared(name):
            guess = similar(name, self.declared_names(), cutoff=0.85)
            if guess:
                self.fix(ln, f'"{name}" \u2192 corrected to "{guess}"')
                name = guess
        target = Tok("ident", name)
        if op == "=":
            new = [target, Tok("op", "=")] + self.fix_expr(ln, rest)
        elif op in ("++", "--"):
            sign = op[0]
            new = [target, Tok("op", "="), target, Tok("op", sign), Tok("number", "1")]
            self.fix(ln, f'"{name}{op}" \u2192 rewritten as "{name} = {name} {sign} 1" (Mentor has no {op})')
        else:
            sign = op[0]
            value = self.fix_expr(ln, rest)
            if len(value) > 1:
                value = [Tok("op", "(")] + value + [Tok("op", ")")]
            new = [target, Tok("op", "="), target, Tok("op", sign)] + value
            self.fix(ln, f'"{op}" \u2192 rewritten as "{name} = {name} {sign} ..." (Mentor has no {op})')
        if not self.is_declared(name):
            self.fix(ln, f'"{name}" was used before it was created \u2014 added "var" in front of it')
            new = [Tok("ident", "var")] + new
            self.declare(name)
        return new

    # -- expressions ----------------------------------------------------------------

    def fix_expr(self, ln, toks, cond=False):
        out, depth, prev = [], 0, None
        for t in toks:
            if t.kind == "string":
                t = self.fix_string(ln, t)
            elif t.kind == "ident":
                t = self.fix_ident(ln, t, prev)
            elif t.kind == "other":
                self.fix(ln, f'unknown character "{t.text}" \u2014 removed it')
                continue
            elif t.kind == "op":
                if t.text == "&&":
                    self.fix(ln, '"&&" \u2192 corrected to "and"')
                    t = Tok("ident", "and")
                elif t.text == "||":
                    self.fix(ln, '"||" \u2192 corrected to "or"')
                    t = Tok("ident", "or")
                elif t.text == "=" and cond:
                    self.fix(ln, '"=" \u2192 corrected to "==" (use == to compare two values)')
                    t = Tok("op", "==")
                elif t.text == "(":
                    depth += 1
                elif t.text == ")":
                    if depth == 0:
                        self.fix(ln, 'extra ")" \u2014 removed it')
                        continue
                    depth -= 1
            out.append(t)
            prev = t
        if depth > 0:
            self.fix(ln, 'missing ")" \u2014 added it')
            out.extend([Tok("op", ")")] * depth)
        return out

    def fix_string(self, ln, t):
        s = t.text
        quote, body = s[0], s[1:]
        closed = bool(body) and body.endswith(quote)
        if closed:
            body = body[:-1]
        new = '"' + body.replace('"', "'") + '"'
        if quote == "'":
            self.fix(ln, f'{s} \u2192 corrected to {new} (Mentor text uses double quotes)')
        elif not closed:
            self.fix(ln, f'the text {new} was missing its closing quote \u2014 added it')
        return Tok("string", new)

    def fix_ident(self, ln, t, prev):
        w, lw = t.text, t.text.lower()
        if lw in ("true", "false", "and", "or"):
            if w != lw:
                self.fix(ln, f'"{w}" \u2192 corrected to "{lw}"')
                return Tok("ident", lw)
            return t
        if lw in KEYWORDS or w in self.names:
            return t
        if prev is not None and is_operand(prev):
            guess = similar(w, ["and", "or"])
        else:
            guess = similar(w, sorted(self.names) + ["true", "false"], cutoff=0.8)
        if guess:
            self.fix(ln, f'"{w}" \u2192 corrected to "{guess}"')
            return Tok("ident", guess)
        return t


def recover(source):
    """Fix the common mistakes in Mentor source code."""
    return Recovery(source).run()


# ---------------------------------------------------------------------------
# Lexer
# ---------------------------------------------------------------------------

Token = namedtuple("Token", "kind text line")


def lex(source):
    tokens, last = [], 1
    for ln, line in enumerate(source.splitlines(), 1):
        last = ln
        toks, _ = tokenize_line(line)
        for t in toks:
            kind = t.kind
            if kind == "other":
                raise MentorError(ln, f'I don\'t understand the character "{t.text}".')
            if kind == "string":
                if len(t.text) < 2 or t.text[0] != '"' or t.text[-1] != '"':
                    raise MentorError(ln, "This text needs double quotes at both ends, like \"hello\".")
            if kind == "ident" and t.text in KEYWORDS:
                kind = "kw"
            tokens.append(Token(kind, t.text, ln))
        if toks:
            tokens.append(Token("newline", "\n", ln))
    tokens.append(Token("eof", "", last))
    return tokens


# ---------------------------------------------------------------------------
# Syntax tree
# ---------------------------------------------------------------------------

@dataclass
class Num:
    value: object
    line: int

@dataclass
class Str:
    value: str
    line: int

@dataclass
class Bool:
    value: bool
    line: int

@dataclass
class Name:
    name: str
    line: int

@dataclass
class Unary:
    op: str
    operand: object
    line: int

@dataclass
class Binary:
    op: str
    left: object
    right: object
    line: int

@dataclass
class Call:
    name: str
    args: list
    line: int

@dataclass
class VarStmt:
    name: str
    value: object
    line: int

@dataclass
class AssignStmt:
    name: str
    value: object
    line: int

@dataclass
class PrintStmt:
    args: list
    line: int

@dataclass
class IfStmt:
    cond: object
    body: list
    orelse: list
    line: int

@dataclass
class WhileStmt:
    cond: object
    body: list
    line: int

@dataclass
class FuncStmt:
    name: str
    params: list
    body: list
    line: int

@dataclass
class ReturnStmt:
    value: object
    line: int

@dataclass
class ExprStmt:
    expr: object
    line: int


# ---------------------------------------------------------------------------
# Parser (recursive descent)
# ---------------------------------------------------------------------------

class Parser:
    def __init__(self, tokens):
        self.toks = tokens
        self.pos = 0

    def peek(self, offset=0):
        return self.toks[min(self.pos + offset, len(self.toks) - 1)]

    def next(self):
        t = self.toks[self.pos]
        if t.kind != "eof":
            self.pos += 1
        return t

    def is_kw(self, *words):
        t = self.peek()
        return t.kind == "kw" and t.text in words

    def is_op(self, *ops):
        t = self.peek()
        return t.kind == "op" and t.text in ops

    @staticmethod
    def describe(t):
        return "the end of the line" if t.kind in ("newline", "eof") else f'"{t.text}"'

    def expect_kw(self, word, why):
        if self.is_kw(word):
            return self.next()
        t = self.peek()
        raise MentorError(t.line, f'I expected "{word}" {why}, but found {self.describe(t)}.')

    def expect_op(self, op, why):
        if self.is_op(op):
            return self.next()
        t = self.peek()
        raise MentorError(t.line, f'I expected "{op}" {why}, but found {self.describe(t)}.')

    def skip_newlines(self):
        while self.peek().kind == "newline":
            self.pos += 1

    def end_of_statement(self):
        t = self.peek()
        if t.kind == "newline":
            self.pos += 1
        elif t.kind != "eof":
            raise MentorError(t.line, f'I didn\'t expect "{t.text}" here. Is something missing before it?')

    def program(self):
        stmts = []
        self.skip_newlines()
        while self.peek().kind != "eof":
            stmts.append(self.statement())
            self.skip_newlines()
        return stmts

    def block(self, opener_line, kind, stop=("end",)):
        stmts = []
        self.skip_newlines()
        while True:
            t = self.peek()
            if t.kind == "eof":
                raise MentorError(opener_line, f'This {kind} is never closed with "end".')
            if t.kind == "kw" and t.text in stop:
                return stmts
            stmts.append(self.statement())
            self.skip_newlines()

    def statement(self):
        t = self.peek()
        if t.kind == "kw":
            k = t.text
            if k == "var":
                self.next()
                name = self.next()
                if name.kind != "ident":
                    raise MentorError(t.line, '"var" must be followed by a name, like: var score = 0')
                self.expect_op("=", f'after "var {name.text}"')
                value = self.expression()
                self.end_of_statement()
                return VarStmt(name.text, value, t.line)
            if k == "print":
                self.next()
                args = []
                if self.peek().kind not in ("newline", "eof"):
                    args.append(self.expression())
                    while self.is_op(","):
                        self.next()
                        args.append(self.expression())
                self.end_of_statement()
                return PrintStmt(args, t.line)
            if k == "if":
                self.next()
                cond = self.expression()
                self.expect_kw("then", "after the if condition")
                self.end_of_statement()
                body = self.block(t.line, "if", stop=("else", "end"))
                orelse = []
                if self.is_kw("else"):
                    self.next()
                    self.end_of_statement()
                    orelse = self.block(t.line, "if")
                self.expect_kw("end", "to finish the if")
                self.end_of_statement()
                return IfStmt(cond, body, orelse, t.line)
            if k == "while":
                self.next()
                cond = self.expression()
                self.expect_kw("then", "after the while condition")
                self.end_of_statement()
                body = self.block(t.line, "while")
                self.expect_kw("end", "to finish the while")
                self.end_of_statement()
                return WhileStmt(cond, body, t.line)
            if k == "func":
                self.next()
                name = self.next()
                if name.kind != "ident":
                    raise MentorError(t.line, '"func" must be followed by a name, like: func add(a, b)')
                self.expect_op("(", f'after the function name "{name.text}"')
                params = []
                while not self.is_op(")"):
                    p = self.next()
                    if p.kind != "ident":
                        raise MentorError(p.line, "Function parameters must be names, separated by commas.")
                    params.append(p.text)
                    if self.is_op(","):
                        self.next()
                    elif not self.is_op(")"):
                        raise MentorError(p.line, "Function parameters must be separated by commas.")
                self.expect_op(")", "to close the parameter list")
                self.end_of_statement()
                body = self.block(t.line, "func")
                self.expect_kw("end", "to finish the function")
                self.end_of_statement()
                return FuncStmt(name.text, params, body, t.line)
            if k == "return":
                self.next()
                value = None
                if self.peek().kind not in ("newline", "eof"):
                    value = self.expression()
                self.end_of_statement()
                return ReturnStmt(value, t.line)
            if k == "end":
                raise MentorError(t.line, '"end" has nothing to close here.')
            if k == "else":
                raise MentorError(t.line, '"else" must come after an "if" block.')
            raise MentorError(t.line, f'"{k}" can\'t start a statement here.')
        if t.kind == "ident" and self.peek(1).kind == "op" and self.peek(1).text == "=":
            self.next()
            self.next()
            value = self.expression()
            self.end_of_statement()
            return AssignStmt(t.text, value, t.line)
        expr = self.expression()
        self.end_of_statement()
        return ExprStmt(expr, t.line)

    # expressions, lowest to highest precedence
    def expression(self):
        left = self.and_expr()
        while self.is_kw("or"):
            op = self.next()
            left = Binary("or", left, self.and_expr(), op.line)
        return left

    def and_expr(self):
        left = self.equality()
        while self.is_kw("and"):
            op = self.next()
            left = Binary("and", left, self.equality(), op.line)
        return left

    def equality(self):
        left = self.comparison()
        while self.is_op("==", "!="):
            op = self.next()
            left = Binary(op.text, left, self.comparison(), op.line)
        return left

    def comparison(self):
        left = self.term()
        while self.is_op("<", ">", "<=", ">="):
            op = self.next()
            left = Binary(op.text, left, self.term(), op.line)
        return left

    def term(self):
        left = self.factor()
        while self.is_op("+", "-"):
            op = self.next()
            left = Binary(op.text, left, self.factor(), op.line)
        return left

    def factor(self):
        left = self.unary()
        while self.is_op("*", "/", "%"):
            op = self.next()
            left = Binary(op.text, left, self.unary(), op.line)
        return left

    def unary(self):
        if self.is_op("-"):
            op = self.next()
            return Unary("-", self.unary(), op.line)
        return self.primary()

    def primary(self):
        t = self.next()
        if t.kind == "number":
            return Num(float(t.text) if "." in t.text else int(t.text), t.line)
        if t.kind == "string":
            return Str(t.text[1:-1], t.line)
        if t.kind == "kw" and t.text in ("true", "false"):
            return Bool(t.text == "true", t.line)
        if t.kind == "ident":
            if self.is_op("("):
                self.next()
                args = []
                while not self.is_op(")"):
                    args.append(self.expression())
                    if self.is_op(","):
                        self.next()
                    elif not self.is_op(")"):
                        raise MentorError(t.line, f'I expected "," or ")" in the call to "{t.text}", but found {self.describe(self.peek())}.')
                self.next()
                return Call(t.text, args, t.line)
            return Name(t.text, t.line)
        if t.kind == "op" and t.text == "(":
            inner = self.expression()
            self.expect_op(")", "to close the bracket")
            return inner
        raise MentorError(t.line, f'I expected a value here, but found {self.describe(t)}.')


# ---------------------------------------------------------------------------
# Interpreter
# ---------------------------------------------------------------------------

class ReturnSignal(Exception):
    def __init__(self, value):
        self.value = value


@dataclass
class Function:
    name: str
    params: list
    body: list
    closure: object


class Env:
    """A scope: variables of one function (or the whole program)."""

    def __init__(self, parent=None):
        self.vars = {}
        self.parent = parent

    def find(self, name):
        env = self
        while env is not None:
            if name in env.vars:
                return env
            env = env.parent
        return None

    def all_names(self):
        names, env = set(), self
        while env is not None:
            names.update(env.vars)
            env = env.parent
        return names

    def get(self, name, line):
        env = self.find(name)
        if env is None:
            guess = similar(name, self.all_names(), cutoff=0.8)
            hint = (f' Did you mean "{guess}"?' if guess
                    else f' Did you forget to create it first with: var {name} = ...')
            raise MentorError(line, f'I don\'t know what "{name}" is.' + hint)
        return env.vars[name]

    def assign(self, name, value, line):
        env = self.find(name)
        if env is None:
            raise MentorError(line, f'"{name}" doesn\'t exist yet, so I can\'t change it. '
                                    f'Create it first with: var {name} = ...')
        env.vars[name] = value


def is_number(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def truthy(v):
    if v is None:
        return False
    if isinstance(v, bool):
        return v
    if is_number(v):
        return v != 0
    if isinstance(v, str):
        return len(v) > 0
    return True


def fmt(v):
    """How a value looks when printed."""
    if v is None:
        return "none"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, float):
        if math.isfinite(v) and v == int(v) and abs(v) < 1e15:
            return str(int(v))
        return format(v, ".10g")
    if isinstance(v, Function):
        return f"<function {v.name}>"
    return str(v)


def type_name(v):
    if is_number(v):
        return "a number"
    if isinstance(v, bool):
        return "true/false"
    if isinstance(v, str):
        return "text"
    return "a value"


class Interpreter:
    def __init__(self, write=None):
        self.write = write or sys.stdout.write
        self.globals = Env()
        self.steps = 0
        self.depth = 0

    def run(self, program):
        self.hoist(program, self.globals)
        self.exec_block(program, self.globals)

    def hoist(self, stmts, env):
        """Functions can be called before the line that defines them."""
        for s in stmts:
            if isinstance(s, FuncStmt):
                env.vars[s.name] = Function(s.name, s.params, s.body, env)

    def tick(self, line):
        self.steps += 1
        if self.steps > MAX_STEPS:
            raise MentorError(line, "This program has been running for a very long time. "
                                    "Is there a loop that never stops?")

    # -- statements --

    def exec_block(self, stmts, env):
        for s in stmts:
            self.exec(s, env)

    def exec(self, s, env):
        self.tick(s.line)
        if isinstance(s, VarStmt):
            env.vars[s.name] = self.eval(s.value, env)
        elif isinstance(s, AssignStmt):
            env.assign(s.name, self.eval(s.value, env), s.line)
        elif isinstance(s, PrintStmt):
            self.write(" ".join(fmt(self.eval(a, env)) for a in s.args) + "\n")
        elif isinstance(s, IfStmt):
            if truthy(self.eval(s.cond, env)):
                self.exec_block(s.body, env)
            else:
                self.exec_block(s.orelse, env)
        elif isinstance(s, WhileStmt):
            while truthy(self.eval(s.cond, env)):
                self.tick(s.line)
                self.exec_block(s.body, env)
        elif isinstance(s, FuncStmt):
            env.vars[s.name] = Function(s.name, s.params, s.body, env)
        elif isinstance(s, ReturnStmt):
            raise ReturnSignal(self.eval(s.value, env) if s.value is not None else None)
        elif isinstance(s, ExprStmt):
            self.eval(s.expr, env)

    # -- expressions --

    def eval(self, n, env):
        if isinstance(n, (Num, Str, Bool)):
            return n.value
        if isinstance(n, Name):
            return env.get(n.name, n.line)
        if isinstance(n, Unary):
            v = self.eval(n.operand, env)
            if not is_number(v):
                raise MentorError(n.line, f"I can only put a minus sign in front of a number, not {type_name(v)}.")
            return -v
        if isinstance(n, Binary):
            return self.binary(n, env)
        if isinstance(n, Call):
            return self.call(n, env)
        raise MentorError(getattr(n, "line", 0), "I don't know how to run this.")

    def binary(self, n, env):
        op = n.op
        left = self.eval(n.left, env)
        if op == "and":
            return truthy(left) and truthy(self.eval(n.right, env))
        if op == "or":
            return truthy(left) or truthy(self.eval(n.right, env))
        right = self.eval(n.right, env)
        if op == "==":
            return left == right and (is_number(left) == is_number(right))
        if op == "!=":
            return not (left == right and (is_number(left) == is_number(right)))
        if op == "+" and (isinstance(left, str) or isinstance(right, str)):
            return fmt(left) + fmt(right)
        if op in ("<", ">", "<=", ">="):
            ok = (is_number(left) and is_number(right)) or (isinstance(left, str) and isinstance(right, str))
            if not ok:
                raise MentorError(n.line, f"I can't compare {type_name(left)} with {type_name(right)}.")
            return {"<": left < right, ">": left > right, "<=": left <= right, ">=": left >= right}[op]
        if not (is_number(left) and is_number(right)):
            raise MentorError(n.line, f'I can only use "{op}" with numbers, but got {type_name(left)} and {type_name(right)}.')
        if op == "+":
            return left + right
        if op == "-":
            return left - right
        if op == "*":
            return left * right
        if op in ("/", "%"):
            if right == 0:
                raise MentorError(n.line, "You can't divide by zero.")
            if op == "%":
                return left % right
            if isinstance(left, int) and isinstance(right, int) and left % right == 0:
                return left // right
            return left / right
        raise MentorError(n.line, f'I don\'t know the operator "{op}".')

    def call(self, n, env):
        fn = env.get(n.name, n.line) if env.find(n.name) else None
        if fn is None:
            guess = similar(n.name, [k for k in env.all_names() if isinstance(env.get(k, 0), Function)], cutoff=0.7)
            hint = f' Did you mean "{guess}"?' if guess else ""
            raise MentorError(n.line, f'I don\'t know a function called "{n.name}".' + hint)
        if not isinstance(fn, Function):
            raise MentorError(n.line, f'"{n.name}" is not a function, so it can\'t be called.')
        args = [self.eval(a, env) for a in n.args]
        if len(args) != len(fn.params):
            plural = "value" if len(fn.params) == 1 else "values"
            raise MentorError(n.line, f'"{fn.name}" needs {len(fn.params)} {plural} but got {len(args)}.')
        if self.depth >= MAX_DEPTH:
            raise MentorError(n.line, f'"{fn.name}" keeps calling itself and never stops. '
                                      'Does it have a case where it returns without calling itself?')
        local = Env(fn.closure)
        for p, v in zip(fn.params, args):
            local.vars[p] = v
        self.hoist(fn.body, local)
        self.depth += 1
        try:
            self.exec_block(fn.body, local)
        except ReturnSignal as r:
            return r.value
        finally:
            self.depth -= 1
        return None


# ---------------------------------------------------------------------------
# Putting it all together
# ---------------------------------------------------------------------------

def format_report(result, running=True):
    """The mentor's explanation of what it fixed."""
    lines = ["I fixed these mistakes:"]
    lines += [f"{i}. {f}" for i, f in enumerate(result.fixes, 1)]
    lines += ["", "Corrected code:", result.code.rstrip("\n")]
    if running:
        lines += ["", "Running the program..."]
    return "\n".join(lines)


def run_source(source, strict=False, check_only=False, stdout=None, stderr=None):
    """Fix (unless strict), then run. Returns (ok, RecoveryResult or None)."""
    stdout = stdout or sys.stdout
    stderr = stderr or sys.stderr
    sys.setrecursionlimit(max(sys.getrecursionlimit(), 10000))

    result, code = None, source
    if not strict:
        result = recover(source)
        if result.fixes:
            code = result.code
            print(format_report(result, running=not check_only), file=stdout)
        elif check_only:
            print("No mistakes found. Nice work!", file=stdout)
    if check_only:
        return True, result

    corrected = bool(result and result.fixes)
    try:
        program = Parser(lex(code)).program()
        Interpreter(write=stdout.write).run(program)
    except MentorError as e:
        stdout.flush()
        code_lines = code.splitlines()
        where = f"line {e.line}" + (" of the corrected code" if corrected else "")
        print(f"\nOops! There is a problem on {where}:", file=stderr)
        if 1 <= e.line <= len(code_lines):
            print(f"    {code_lines[e.line - 1].strip()}", file=stderr)
        print(e.message, file=stderr)
        return False, result
    except RecursionError:
        print("\nOops! Something is nested too deeply. Does a function call itself forever?", file=stderr)
        return False, result
    return True, result


def main(argv=None):
    ap = argparse.ArgumentParser(
        prog="mentor",
        description="Mentor - a programming language that mentors you.",
    )
    ap.add_argument("file", help="a .mentor program")
    ap.add_argument("--check", action="store_true", help="show the fixes but don't run the program")
    ap.add_argument("--write", action="store_true", help="save the corrected code back into the file")
    ap.add_argument("--strict", action="store_true", help="turn off automatic mistake fixing")
    ap.add_argument("--version", action="version", version=f"Mentor {__version__}")
    args = ap.parse_args(argv)

    try:
        with open(args.file, encoding="utf-8") as f:
            source = f.read()
    except OSError as e:
        print(f"I couldn't open '{args.file}': {e.strerror}", file=sys.stderr)
        return 2

    ok, result = run_source(source, strict=args.strict, check_only=args.check)
    if args.write and result and result.fixes:
        with open(args.file, "w", encoding="utf-8") as f:
            f.write(result.code)
        print(f"\n(Saved the corrected code to {args.file})")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
