# Contributing to Mentor

Thanks for helping make Mentor friendlier for beginners!

## Run the tests

```bash
python -m unittest discover -s tests
```

## Good first contributions

- **A new recoverable mistake.** Watch beginners (or yourself) and note what they get wrong.
  Add the fix in the `Recovery` class in `mentor.py` and a test in `tests/test_mentor.py`.
- **Clearer messages.** Every fix and error should read like a kind teacher wrote it.
- **More example programs** in `examples/`.

## Rules of thumb for recovery fixes

1. Only fix when you are confident. A wrong fix is worse than a clear error.
2. Never change what a correct program does.
3. Always record the fix with `self.fix(line, message)` so the user sees it.
4. Add a test.
