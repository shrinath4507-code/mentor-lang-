# How mistake recovery works

Mentor's compiler runs a **recovery pass** before the parser. It reads the program line by line,
rewrites mistakes it is sure about, and records each change as `Line N: ...`.

## Steps
1. **Pre-scan**: collect every variable, parameter and function name the program creates.
2. **Fix each line**: figure out which statement it is, then repair it.
3. **Close blocks**: add `end` where blocks were never closed.
4. **Report**: list every fix, show the corrected code (re-indented), then run it.

## How it decides
- **Typos** use a "did you mean" match: swapped letters (`pritn`), missing or extra letters (`prnt`, `printt`), wrong case.
- **Names** that are close to a name you already created are corrected (`scroe` to `score`).
  A name is only corrected if it is not itself a name the program creates.
- **Missing `end`**: if the body of a block is indented and a later line is not, `end` goes right before that line.
  If the code is not indented, `end` goes at the end of the file.
- **Foreign keywords** such as `let`, `def`, `echo`, `elif` are translated.

## What it will not fix
Mentor does not guess when the intent is unclear (for example a completely unknown word).
Those cases produce a plain-English error that shows the line of code.

## Adding a new fix
1. Find the matching `stmt_*` method in `Recovery` (or `fix_expr` for expressions) in `mentor.py`.
2. Make the change and call `self.fix(line, "message")`.
3. Add a test in `tests/test_mentor.py`.
