# Launch kit

Everything you need to publish Mentor. Replace `YOUR-USERNAME` and `YOUR NAME` first
(in `LICENSE` and `README.md`).

## 1. Publish on GitHub

```bash
cd mentor-lang
git init
git add .
git commit -m "Mentor 0.1.0: a language that mentors you"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/mentor-lang.git
git push -u origin main
git tag v0.1.0 && git push --tags
```

- **Description:** A beginner programming language whose compiler fixes your mistakes, explains them, then runs your code.
- **Topics:** `programming-language`, `interpreter`, `education`, `beginners`, `python`, `compiler`, `error-recovery`
- Create a **Release** from the `v0.1.0` tag.
- Turn on **Discussions** and add 3 to 5 issues labelled `good first issue` (new mistake to recover from, new example, clearer message).

## 2. Before you post
- [ ] Record a short terminal GIF of `python mentor.py examples/mistakes.mentor` and put it at the top of the README.
- [ ] Run `python -m unittest discover -s tests` once more.
- [ ] Read each subreddit's current rules. Many limit self-promotion, so be ready to join in the discussion.
- [ ] Reply to comments quickly in the first few hours.

## 3. Reddit

### r/ProgrammingLanguages (technical angle)
**Title:** Mentor: a small language whose compiler repairs beginner mistakes and explains the fixes

> I've been building Mentor, an educational language where the front end does error *recovery* instead of just error *reporting*. Before parsing, a recovery pass fixes typo'd keywords, missing `then`/`end`, undeclared assignments, unbalanced quotes and brackets, and a few foreign-language habits (`+=`, `elif`, `&&`). It prints a numbered list of each fix, shows the corrected program, and runs it.
>
> Design questions I'd love feedback on:
> - Is fixing before parsing (line-based, with indentation hints for `end`) a sane approach, or would grammar-based repair in the parser be better?
> - Where should auto-fixing stop? A wrong "fix" is worse than a clear error.
> - What other classic beginner mistakes should it recover from?
>
> It's a ~1000-line Python tree-walking interpreter, MIT licensed: https://github.com/YOUR-USERNAME/mentor-lang

### r/learnprogramming (learner angle; check their rules on projects first)
**Title:** I made a tiny language for beginners where the compiler fixes your mistakes and tells you what it fixed

> When I started coding, error messages were the hardest part. So I built Mentor, a small language where typos like `pritn` and a missing `then` or `end` are fixed automatically, with a plain-English list of what changed and the corrected code.
>
> Would this have helped you when you started? What mistakes did you make most often? I'd like to add them. https://github.com/YOUR-USERNAME/mentor-lang

## 4. X / Twitter thread
1. I built a programming language that mentors you. 🧵
   Make a mistake and the compiler doesn't just error: it fixes it, explains what it fixed, shows the corrected code, then runs it. It's called Mentor. [GIF]
2. You write `vr x = 10`, `pritn x`, and an `if` with no `then` or `end`.
   Mentor replies: "I fixed these mistakes: 1. vr → var 2. pritn → print 3. added then 4. added end". Then it runs the program.
3. It handles typos, missing then/end (using your indentation), forgotten `var`, `=` vs `==`, `x += 1`, missing quotes and brackets.
4. Built for students: simple syntax, `end` instead of braces, friendly errors with "did you mean...?".
5. Pure Python, no dependencies, MIT licensed. Try it and tell me which beginner mistake I should fix next: https://github.com/YOUR-USERNAME/mentor-lang

## 5. Hacker News
**Title:** Show HN: Mentor, a beginner language whose compiler fixes your mistakes
First comment: a short note on why (error messages are the hardest part for new programmers), how recovery works, and what it deliberately does not fix.

## 6. Dev.to article outline
1. Why beginners get stuck on error messages
2. The idea: recover, explain, then run
3. How the recovery pass works (pre-scan, per-line fixes, indentation-based `end`)
4. Where auto-fixing should stop
5. Try it + roadmap
