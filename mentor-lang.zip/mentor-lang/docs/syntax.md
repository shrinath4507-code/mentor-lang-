# Mentor syntax reference

## Comments
```text
# everything after a hash is ignored
```

## Values
| Kind | Examples |
|---|---|
| number | `10`, `3.14` |
| text | `"hello"` (double quotes) |
| boolean | `true`, `false` |

`print` shows numbers without needless decimals (`10`, not `10.0`) and booleans as `true` / `false`.

## Variables
```text
var score = 0      # create
score = score + 1  # change
```
Changing a variable that was never created is a mistake. Mentor adds `var` for you and tells you.

## Print
```text
print "Hello"
print "Total:", 3 + 4     # several values are separated by spaces
```

## Operators (highest priority first)
| Operators | Meaning |
|---|---|
| `-x` | negative |
| `*  /  %` | multiply, divide, remainder |
| `+  -` | add, subtract (`+` joins text too: `"a" + 1` gives `a1`) |
| `<  >  <=  >=` | compare |
| `==  !=` | equal, not equal |
| `and` | both true |
| `or` | at least one true |

Division gives a whole number when it divides evenly (`10 / 5` is `2`), otherwise a decimal.
Conditions treat `0`, empty text and `false` as false. Everything else is true.

## if / else
```text
if x > 5 then
  print "big"
else
  print "small"
end
```
`else` is optional. For several cases, nest an `if` inside the `else`.

## while
```text
while x > 0 then
  x = x - 1
end
```

## Functions
```text
func add(a, b)
  return a + b
end
print add(3, 7)
```
- Functions can be called before the line that defines them.
- Variables created inside a function stay inside it.
- A function without `return` gives back `none`.
- Functions can call themselves (recursion).

## Keywords
`var print if then else end while func return and or true false`

## Safety nets
Programs stop with a friendly message if a loop runs for an extremely long time or a function
calls itself without ever stopping.
