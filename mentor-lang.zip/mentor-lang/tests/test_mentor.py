import io
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import mentor  # noqa: E402


def run(source, **kw):
    out, err = io.StringIO(), io.StringIO()
    ok, result = mentor.run_source(source, stdout=out, stderr=err, **kw)
    return ok, out.getvalue(), err.getvalue(), result


class RecoveryTests(unittest.TestCase):
    def test_spec_example(self):
        src = 'vr x = 10\npritn x\nif x > 5\n print "hello"\n'
        result = mentor.recover(src)
        self.assertEqual(
            result.code,
            'var x = 10\nprint x\nif x > 5 then\n  print "hello"\nend\n',
        )
        self.assertEqual(len(result.fixes), 4)
        ok, out, _, _ = run(src)
        self.assertTrue(ok)
        self.assertTrue(out.rstrip().endswith("10\nhello"))
        self.assertIn("I fixed these mistakes:", out)

    def test_clean_code_has_no_fixes(self):
        src = 'var x = 1\nif x == 1 then\n  print "one"\nend\n'
        self.assertEqual(mentor.recover(src).fixes, [])

    def test_keyword_typos(self):
        src = "var n = 3\nwhlie n > 0 then\n  n = n - 1\nend\nfucn f(a)\n  retrun a\nend\nprint f(n)\n"
        ok, out, err, result = run(src)
        self.assertTrue(ok, err)
        self.assertTrue(out.rstrip().endswith("0"))
        self.assertEqual(len(result.fixes), 3)

    def test_assignment_without_var(self):
        ok, out, _, result = run("x = 5\nprint x\n")
        self.assertTrue(ok)
        self.assertIn("var", result.code)
        self.assertTrue(out.rstrip().endswith("5"))

    def test_variable_typo_in_expression(self):
        ok, out, _, _ = run("var total = 4\nprint totl + 1\n")
        self.assertTrue(ok)
        self.assertTrue(out.rstrip().endswith("5"))

    def test_single_equals_in_condition(self):
        ok, out, _, _ = run('var x = 3\nif x = 3 then\n  print "yes"\nend\n')
        self.assertTrue(ok)
        self.assertTrue(out.rstrip().endswith("yes"))

    def test_missing_paren_and_quote(self):
        ok, out, _, _ = run('print "hi\nprint (1 + 2\n')
        self.assertTrue(ok)
        self.assertTrue(out.rstrip().endswith("hi\n3"))

    def test_end_placed_by_indentation(self):
        src = 'var x = 1\nif x > 0 then\n  print "a"\nprint "b"\n'
        result = mentor.recover(src)
        self.assertEqual(result.code, 'var x = 1\nif x > 0 then\n  print "a"\nend\nprint "b"\n')

    def test_extra_end_removed(self):
        ok, out, _, result = run('print "a"\nend\n')
        self.assertTrue(ok)
        self.assertEqual(len(result.fixes), 1)

    def test_else_if(self):
        src = ('var n = 5\nif n < 3 then\n  print "small"\nelse if n < 10 then\n'
               '  print "medium"\nelse\n  print "large"\nend\n')
        ok, out, err, _ = run(src)
        self.assertTrue(ok, err)
        self.assertTrue(out.rstrip().endswith("medium"))

    def test_plus_equals_and_increment(self):
        ok, out, _, _ = run("var x = 1\nx += 2\nx++\nprint x\n")
        self.assertTrue(ok)
        self.assertTrue(out.rstrip().endswith("4"))

    def test_one_line_if(self):
        ok, out, _, _ = run('var x = 9\nif x > 5 then print "big" end\n')
        self.assertTrue(ok)
        self.assertTrue(out.rstrip().endswith("big"))

    def test_and_or_typos(self):
        ok, out, _, _ = run('var a = 1\nif a > 0 adn a < 5 then\n  print "ok"\nend\n')
        self.assertTrue(ok)
        self.assertTrue(out.rstrip().endswith("ok"))


class RunTests(unittest.TestCase):
    def test_arithmetic(self):
        ok, out, _, _ = run("print 2 + 3 * 4\nprint (2 + 3) * 4\nprint 10 / 4\nprint 10 / 5\nprint 7 % 3\nprint -3 + 1\n")
        self.assertEqual(out, "14\n20\n2.5\n2\n1\n-2\n")

    def test_strings_and_booleans(self):
        ok, out, _, _ = run('print "a" + "b"\nprint "n=" + 5\nprint 1 < 2\nprint true and false\n')
        self.assertEqual(out, "ab\nn=5\ntrue\nfalse\n")

    def test_functions_and_recursion(self):
        src = "func fact(n)\n  if n <= 1 then\n    return 1\n  end\n  return n * fact(n - 1)\nend\nprint fact(6)\n"
        self.assertEqual(run(src)[1], "720\n")

    def test_call_before_definition(self):
        self.assertEqual(run("print hi()\nfunc hi()\n  return 1\nend\n")[1], "1\n")

    def test_examples_run(self):
        folder = os.path.join(os.path.dirname(__file__), "..", "examples")
        for name in sorted(os.listdir(folder)):
            with open(os.path.join(folder, name), encoding="utf-8") as f:
                ok, _, err, _ = run(f.read())
            self.assertTrue(ok, f"{name}: {err}")


class ErrorTests(unittest.TestCase):
    def test_divide_by_zero(self):
        ok, _, err, _ = run("print 1 / 0\n")
        self.assertFalse(ok)
        self.assertIn("divide by zero", err)

    def test_unknown_name_hint(self):
        ok, _, err, _ = run("var apple = 1\nprint banana\n")
        self.assertFalse(ok)
        self.assertIn("banana", err)

    def test_wrong_argument_count(self):
        ok, _, err, _ = run("func f(a, b)\n  return a\nend\nprint f(1)\n")
        self.assertFalse(ok)
        self.assertIn("needs 2 values", err)

    def test_infinite_loop_is_stopped(self):
        ok, _, err, _ = run("while true then\n  var x = 1\nend\n")
        self.assertFalse(ok)
        self.assertIn("never stops", err)

    def test_infinite_recursion_is_stopped(self):
        ok, _, err, _ = run("func f(n)\n  return f(n + 1)\nend\nprint f(1)\n")
        self.assertFalse(ok)
        self.assertIn("never stops", err)

    def test_strict_mode_does_not_fix(self):
        ok, _, err, result = run("pritn 1\n", strict=True)
        self.assertFalse(ok)
        self.assertIsNone(result)


if __name__ == "__main__":
    unittest.main()
